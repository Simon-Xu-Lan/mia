	function changeStyle(element) {
		element.style.color = "#FF0000";
	} 
	
	function changeColor(element) {
		element.style.color = "#0000FF";
	} 
	
		
	function checkName() 
	{
    		var n = document.getElementById("name").value;
	    	if (n == "Jai")
	        	window.alert ("You are Jai");
		else
         		window.alert ("You are NOT Jai");
	}
