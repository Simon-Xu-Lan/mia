"""
Determine speeding find based on speed input.

Things to note:
The input speed is mph
The speed limit is in kph

Pseudocode
function main
    speed_in_mph = get_valid_number("speed in mph")
    speed_limit_in_kph = get_valid_number("speed limit in kph")
    speed_in_kph = convert_miles_to_km(speed_in_mph)
    fine = determine_fine(speed_in_km, speed_limit_in_kph)
    print fine

function get_valid_number(prompt)
    get speed
    while speed < 0 or speed > 150
        print "invalid input"
        get speed
    return speed

function convert_miles_to_km(speed_in_mph)
    return speed_in_mph * 1.60934

function determine_fine(speed_in_km, speed_limit_in_kph)
    speed_over_limit = speed_in_km - speed_limit_in_kph
    if speed_over_limit < 13
        fine = 177
    else if speed_over_limit <= 20
        fine = 266
    else if speed_over_limit <= 30
        fine = 444
    else if speed_over_limit <= 40
        fine = 622
    else
        find = 1245

    return fine
"""

def main():
    speed_in_mph = float(get_valid_number("speed in mph: "))
    speed_limit_in_kph = float(get_valid_number("speed limit in kph: "))
    speed_in_kph = convert_miles_to_km(speed_in_mph)
    fine = determine_fine(speed_in_kph, speed_limit_in_kph)
    print(fine)


def get_valid_number(prompt):
    speed = float(input(prompt))
    while speed < 0 or speed > 150:
        print
        "invalid input"
        speed = float(input(prompt))
    return speed


def convert_miles_to_km(speed_in_mph):
    return speed_in_mph * 1.60934


def determine_fine(speed_in_km, speed_limit_in_kph):
    speed_over_limit = speed_in_km - speed_limit_in_kph
    if speed_over_limit < 13:
        fine = 177
    elif speed_over_limit <= 20:
        fine = 266
    elif speed_over_limit <= 30:
        fine = 444
    elif speed_over_limit <= 40:
        fine = 622
    else:
        fine = 1245

    return fine


main()